
<?php

$connection=mysqli_connect('localhost','root', '','sukaina zehra');

if ($connection){ 
  echo "connected";
}

else{
die("connection failed");
};
?>