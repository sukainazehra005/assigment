<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Employee Records</title>
</head>
<body>
<h5> Search Employee Records</h5>
<?php

include('connection.php');
$query="SELECT * FROM salarychart";

$res=mysqli_query($connection,$query);
if(!$res){

  die('query failed'.mysqli_error());

}


if(isset($_POST['submit'])){
$name = $_POST['search'];

if(empty($name)){
	echo "it's empty";
}
else{
	;
	$selected_data = "SELECT * FROM salarychart WHERE name LIKE '%$name%' || salary LIKE '%$name%'";
	$result = mysqli_query($connection,$selected_data);
	
	if($row = mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_assoc($result)){
?>
<tr>
	<td><?php	echo $row['id'];?></td>
	<td><?php	echo $row['name'];?></td>
    <td><?php    echo $row['salary'];?></td>
	</tr>
	<?php	
	}
}
else{
echo "no result found";
}
}
}




?>
<form action="" method="post">
<input type="text" name="search" placeholder="Enter search value">
<input type="submit" name="submit" value="Search">
</form>



<body>
</html>