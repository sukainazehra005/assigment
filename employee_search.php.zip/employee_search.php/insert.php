<htmL>
<head>
    <title>insert</title>
    </head>
    <body>

<?php
include('connection.php');
if (isset ($_POST ['add'])){
	$name_insert=$_POST['name_edit'];
	$salary_insert=$_POST['salary_edit'];
	


$query_insert="INSERT INTO salarychart (name,salary) ";
$query_insert.="VALUES('$name_insert','$salary_insert')";

$result_insert=mysqli_query($connection,$query_insert);
if($result_insert){

	echo "data saved";
}
};
?>



<form  method='POST'>

    <label for='name'>name</label>
    <input type='text' name='name_edit'>

    <label for ='salary'>salary</label>
    <input type ='text' name='salary_edit'>


    <input type= 'submit' name='add'> 
	 </form>
     </body>
     </html>